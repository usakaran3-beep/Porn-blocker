package com.cleanmind.app

import android.net.VpnService
import android.content.Intent
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

/**
 * Local VPN: sirf DNS traffic pakadta hai aur CleanBrowsing Adult filter ko forward karta hai.
 * Baaki internet normal chalta hai. Saare browsers + Telegram in-app browser + har app cover hota hai.
 */
class DnsVpnService : VpnService() {
    companion object {
        @Volatile var active = false
        const val FAKE_DNS = "10.111.222.3"
        val UPSTREAMS = listOf("185.228.168.10", "185.228.168.11")
    }

    @Volatile private var running = false
    private var tun: ParcelFileDescriptor? = null
    private val pool = Executors.newCachedThreadPool()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!running) start()
        return START_STICKY
    }

    private fun start() {
        tun = Builder()
            .setSession("Clean Mind")
            .addAddress("10.111.222.1", 24)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32)
            .establish() ?: return
        running = true
        active = true
        Thread { loop() }.start()
    }

    private fun loop() {
        val fd = tun ?: return
        val input = FileInputStream(fd.fileDescriptor)
        val out = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        while (running) {
            val n = try { input.read(buf) } catch (e: Exception) { break }
            if (n <= 0) continue
            val pkt = buf.copyOf(n)
            pool.execute { handle(pkt, out) }
        }
        active = false
    }

    private fun u8(b: Byte) = b.toInt() and 0xff

    private fun handle(pkt: ByteArray, out: FileOutputStream) {
        try {
            if ((u8(pkt[0]) shr 4) != 4) return
            val ihl = (u8(pkt[0]) and 0x0f) * 4
            if (u8(pkt[9]) != 17) return
            val dport = (u8(pkt[ihl + 2]) shl 8) or u8(pkt[ihl + 3])
            if (dport != 53) return
            val udpLen = (u8(pkt[ihl + 4]) shl 8) or u8(pkt[ihl + 5])
            val query = pkt.copyOfRange(ihl + 8, ihl + udpLen)

            var reply: ByteArray? = null
            for (up in UPSTREAMS) {
                try {
                    DatagramSocket().use { s ->
                        protect(s)
                        s.soTimeout = 2500
                        s.send(DatagramPacket(query, query.size, InetAddress.getByName(up), 53))
                        val rb = ByteArray(4096)
                        val rp = DatagramPacket(rb, rb.size)
                        s.receive(rp)
                        reply = rb.copyOf(rp.length)
                    }
                    if (reply != null) break
                } catch (_: Exception) {}
            }
            val r = reply ?: return

            val total = 20 + 8 + r.size
            val o = ByteArray(total)
            o[0] = 0x45; o[2] = (total shr 8).toByte(); o[3] = total.toByte()
            o[8] = 64; o[9] = 17
            System.arraycopy(pkt, 16, o, 12, 4) // src = original dst
            System.arraycopy(pkt, 12, o, 16, 4) // dst = original src
            var sum = 0
            for (i in 0 until 20 step 2) sum += (u8(o[i]) shl 8) or u8(o[i + 1])
            while (sum shr 16 != 0) sum = (sum and 0xffff) + (sum shr 16)
            val ck = sum.inv() and 0xffff
            o[10] = (ck shr 8).toByte(); o[11] = ck.toByte()
            o[20] = 0; o[21] = 53
            o[22] = pkt[ihl]; o[23] = pkt[ihl + 1]
            val ul = 8 + r.size
            o[24] = (ul shr 8).toByte(); o[25] = ul.toByte()
            System.arraycopy(r, 0, o, 28, r.size)
            synchronized(out) { out.write(o) }
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        running = false
        active = false
        try { tun?.close() } catch (_: Exception) {}
        pool.shutdownNow()
        super.onDestroy()
    }
}
